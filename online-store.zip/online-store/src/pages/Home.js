import React, { useState } from 'react';

function Home() {
  // State variables to manage username input and login status
  const [username, setUsername] = useState('');
  const [loggedIn, setLoggedIn] = useState(false);

  // Function to handle login
  const handleLogin = () => {
    // Check if username is not empty
    if (username.trim() !== '') {
      // Set loggedIn state to true
      setLoggedIn(true);
    }
  };

  // Function to handle logout
  const handleLogout = () => {
    // Reset username and set loggedIn state to false
    setUsername('');
    setLoggedIn(false);
  };

  return (
    <div className="home">
      {/* Conditional rendering based on login status */}
      {!loggedIn ? (
        // Display login form if not logged in
        <div>
          <input 
            type="text" 
            value={username} 
            onChange={(e) => setUsername(e.target.value)} 
            placeholder="Enter your name"
          />
          <button onClick={handleLogin}>Login</button>
        </div>
      ) : (
        // Display welcome message and logout button if logged in
        <div>
          <h1>Welcome, {username}</h1>
          <button onClick={handleLogout}>Logout</button>
        </div>
      )}
    </div>
  );
}

export default Home;

