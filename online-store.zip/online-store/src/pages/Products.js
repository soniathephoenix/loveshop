import React, { useState } from 'react';
import { Card, Button, Dropdown, DropdownButton } from 'react-bootstrap'; // Import components from react-bootstrap
import TotalPrice from '../components/TotalPrice'; // Import the TotalPrice component
import mug from '../mug.png'; // Import product images
import card from '../card.png';

const products = [
  // Array of product objects, each with an id, title, description, price, image, and available colors
  { id: 1, title: 'Product 1', description: 'Short description of product 1', price: 29.99, img: mug, colors: ['Red', 'Green', 'Blue'] },
  { id: 2, title: 'Product 2', description: 'Short description of product 2', price: 49.99, img: card, colors: ['Yellow', 'Pink', 'Purple'] },
  { id: 3, title: 'Product 3', description: 'Short description of product 3', price: 19.99, img: mug, colors: ['Red', 'Green', 'Blue'] },
  { id: 4, title: 'Product 4', description: 'Short description of product 4', price: 39.99, img: card, colors: ['Yellow', 'Pink', 'Purple'] },
  { id: 5, title: 'Product 5', description: 'Short description of product 5', price: 24.99, img: mug, colors: ['Red', 'Green', 'Blue'] },
  { id: 6, title: 'Product 6', description: 'Short description of product 6', price: 34.99, img: card, colors: ['Yellow', 'Pink', 'Purple'] },
  { id: 7, title: 'Product 7', description: 'Short description of product 7', price: 29.99, img: mug, colors: ['Red', 'Green', 'Blue'] },
  { id: 8, title: 'Product 8', description: 'Short description of product 8', price: 44.99, img: card, colors: ['Yellow', 'Pink', 'Purple'] },
  { id: 9, title: 'Product 9', description: 'Short description of product 9', price: 49.99, img: mug, colors: ['Red', 'Green', 'Blue'] },
  { id: 10, title: 'Product 10', description: 'Short description of product 10', price: 59.99, img: card, colors: ['Yellow', 'Pink', 'Purple'] },
];

function Products({ totalPrice, setTotalPrice }) {
  // State to track selected colors for each product
  const [selectedColors, setSelectedColors] = useState({});

  // Function to handle buying a product, which updates the total price
  const handleBuy = (price) => {
    setTotalPrice(totalPrice + price);
  };

  // Function to handle color selection for a product
  const handleColorSelect = (productId, color) => {
    setSelectedColors({ ...selectedColors, [productId]: color });
  };

  return (
    <div className="products-container">
      {/* Render the TotalPrice component with the current total price */}
      <TotalPrice totalPrice={totalPrice} />
      <div className="product-list" style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', justifyContent: 'center' }}>
        {/* Map through the products array and render a Card for each product */}
        {products.map(product => (
          <Card key={product.id} style={{ width: '18rem' }}>
            <Card.Img variant="top" src={product.img} /> {/* Display product image */}
            <Card.Body>
              <Card.Title>{product.title}</Card.Title> {/* Display product title */}
              <Card.Text>{product.description}</Card.Text> {/* Display product description */}
              <Card.Text>${product.price.toFixed(2)}</Card.Text> {/* Display product price */}
              <DropdownButton 
                id="dropdown-basic-button" 
                title="Choose color"
                // Dynamically set the button variant based on the selected color
                variant={selectedColors[product.id]?.toLowerCase() || 'primary'}
              >
                {/* Map through the colors array and create a Dropdown.Item for each color */}
                {product.colors.map((color, index) => (
                  <Dropdown.Item key={index} onClick={() => handleColorSelect(product.id, color)}>{color}</Dropdown.Item>
                ))}
              </DropdownButton>
              <Button variant="primary" onClick={() => handleBuy(product.price)}>Buy</Button> {/* Button to buy the product */}
            </Card.Body>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default Products; // Export the Products component as the default export
