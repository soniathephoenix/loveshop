import React from 'react';
import { Figure } from 'react-bootstrap'; // Import Figure component from react-bootstrap
import TotalPrice from '../components/TotalPrice'; // Import the TotalPrice component
import logo from '../logo.png'; // Import the logo image
import insideStore from '../gift.png'; // Import the insideStore image
import window from '../window.png'; // Import the window image

function About({ totalPrice }) {
  return (
    <div className="about-container" style={{ padding: '20px' }}>
      {/* Render the TotalPrice component with the current total price */}
      <TotalPrice totalPrice={totalPrice} /> 
      <Figure>
        <Figure.Image
          width={171}
          height={180}
          alt="Store logo"
          src={logo}
        />
        <Figure.Caption>
          Our store logo.
        </Figure.Caption>
      </Figure>
      <p>Welcome to our store. We offer a variety of products to suit your needs. Contact us for more information.</p>
      <Figure>
        <Figure.Image
          width={171}
          height={180}
          alt="Store front"
          src={insideStore}
        />
        <Figure.Caption>
          Our store front.
        </Figure.Caption>
      </Figure>
      <Figure>
        <Figure.Image
          width={171}
          height={180}
          alt="Inside the store"
          src={window}
        />
        <Figure.Caption>
          Inside the store.
        </Figure.Caption>
      </Figure>
      <p>Contact us: +44 7729571893</p>
    </div>
  );
}

export default About; // Export the About component as the default export

