import React, { useState, useEffect } from 'react';

// TotalPrice component displays the total price
// Props:
// - totalPrice: The total price to display
function TotalPrice({ totalPrice }) {
  // State variable to manage visibility, initialized to false
  const [isVisible, setIsVisible] = useState(false);

  // useEffect to update visibility based on the value of totalPrice
  // If totalPrice is greater than zero, set isVisible to true, otherwise false
  useEffect(() => {
    if (totalPrice > 0) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  }, [totalPrice]); // Dependency array includes totalPrice to run effect whenever it changes

  // Conditionally render the component based on the isVisible state
  // Only render the div if isVisible is true
  return (
    isVisible && (
      <div className="total-price">
        <h2>Total price: ${totalPrice.toFixed(2)}</h2> {/* Display total price formatted with two decimal places */}
      </div>
    )
  );
}

export default TotalPrice;

