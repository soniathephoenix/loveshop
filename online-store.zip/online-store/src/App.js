import React, { useState } from 'react';
import './App.css'; // Import CSS styles for the App component
import Header from './components/Header'; // Import the Header component
import { Route, Routes } from 'react-router-dom'; // Import Route and Routes components from react-router-dom
import Home from './pages/Home'; // Import the Home page component
import Products from './pages/Products'; // Import the Products page component
import About from './pages/About'; // Import the About page component

function App() {
  // Create a state variable for totalPrice, which will be shared between components
  const [totalPrice, setTotalPrice] = useState(0);

  return (
    <div className="App">
      <Header /> {/* Render the Header component */}
      <Routes> {/* Define routes for different pages using the Routes component */}
        <Route exact path="/" element={<Home />} /> {/* Define route for the Home page */}
        {/* Pass totalPrice and setTotalPrice as props to the Products component */}
        <Route path="/products" element={<Products totalPrice={totalPrice} setTotalPrice={setTotalPrice} />} />
        {/* Pass totalPrice as a prop to the About component */}
        <Route path="/about" element={<About totalPrice={totalPrice} />} />
      </Routes>
    </div>
  );
}

export default App; // Export the App component as the default export

