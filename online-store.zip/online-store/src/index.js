// Import necessary libraries and components from React and React DOM
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';

// Import the main App component
import App from './App';

// Import CSS styles for the entire application
import './index.css';

// Import Bootstrap CSS to apply Bootstrap styles to the application
import 'bootstrap/dist/css/bootstrap.min.css';

// Import reportWebVitals for measuring performance
import reportWebVitals from './reportWebVitals';

// Create a root element where the entire React application will be rendered
const root = ReactDOM.createRoot(document.getElementById('root'));

// Render the entire React application within the root element
root.render(
  <React.StrictMode>
    {/* Wrap the App component with BrowserRouter to enable routing */}
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);

// Call reportWebVitals function to start measuring performance in the app
reportWebVitals();



